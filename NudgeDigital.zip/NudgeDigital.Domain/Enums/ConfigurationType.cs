﻿namespace NudgeDigital.Domain.Enums
{
    public enum ConfigurationType
    {
        RAM = 1,
        HDD,
        COLOUR
    }
}
