﻿using NudgeDigital.Domain.Common;

namespace NudgeDigital.Domain.Entities
{
    public class Component : AuditableEntity
    {
        public string Name { get; set; }
    }
}
