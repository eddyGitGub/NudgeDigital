﻿namespace NudgeDigital.Application.Features.Brands.Queries
{
    public class BrandVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}