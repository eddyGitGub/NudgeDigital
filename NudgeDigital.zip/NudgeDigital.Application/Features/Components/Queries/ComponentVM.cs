﻿namespace NudgeDigital.Application.Features.Components.Queries
{
    public class ComponentVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}