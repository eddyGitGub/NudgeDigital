﻿namespace NudgeDigital.Application.Features.Configurations.Queries
{
    public class ConfigurationVM
    {
        public int Id { get; set; }
        public int ComponentId { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
    }
}
