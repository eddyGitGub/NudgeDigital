﻿namespace NudgeDigital.Application.Contracts.Infrastructure
{
    public interface ICurrentUserService
    {
        string UserId { get; }
    }
}
